﻿using System;

namespace demo_neuron4
{
    class SimpleDTW
    {
        /* Sequences */
        private double[] x, y;

        /* Sequences lengths */
        private int n, m;

        /* Matrices */
        private double[,] distance, DTW;

        /// <summary>
        /// Constructor of the class.
        /// </summary>
        public SimpleDTW(double[] _x, double[] _y)
        {
            // Get the sequences
            x = _x;
            y = _y;

            // Get the lengths
            n = x.Length;
            m = y.Length;

            // Create and instantiate the distance table
            distance = new double[n, m];
            for (int i = 0; i < n; ++i)
                for (int j = 0; j < m; ++j)
                    distance[i, j] = Math.Abs(x[i] - y[j]);

            // Create the cost matrix
            DTW = new double[n, m];
        }

        /// <summary>
        /// Compute DTW and return the cost between x and y.
        /// </summary>
        public double DTWDistance()
        {
            // First cost [ 0 ; 0 ]
            DTW[0, 0] = 0;

            // Calculating the first line [ 1..n-1 ; 0 ]
            for (int i = 1; i < n; i++)
                DTW[i, 0] = distance[i, 0] + DTW[i - 1, 0];

            // Calculating the first column [ 0 ; 1..m-1 ]
            for (int j = 1; j < m; j++)
                DTW[0, j] = distance[0, j] + DTW[0, j - 1];

            // Calculating the rest [ 1..n ; 1..m ]
            for (int i = 1; i < n; i++)
                for (int j = 1; j < m; j++)
                    DTW[i, j] = distance[i, j] + GetMinValue(DTW[i - 1, j],
                                                             DTW[i, j - 1],
                                                             DTW[i - 1, j - 1]);
            // Return the cost
            return DTW[n - 1, m - 1];
        }

        /// <summary>
        /// Returns the min value between a, b and c.
        /// </summary>
        private double GetMinValue(double a, double b, double c)
        {
            return Math.Min(a, Math.Min(b, c));
        }
    }
}
