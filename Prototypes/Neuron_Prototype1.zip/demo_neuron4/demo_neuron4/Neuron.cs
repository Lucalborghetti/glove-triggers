﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace demo_neuron4
{
    class Neuron
    {
        /* Is listening to user's key */
        private static Boolean listening;

        /* Is gesture capture over */
        private static Boolean isOver;

        /* Is recording for recognition */
        private static Boolean isRecognition;

        /* The number of frame to capture */
        private static int total_frames;

        /* The name of the gesture to capture */
        private static string gesture_name;

        /* The current number of frame retrieved */
        private static int frameCounter;

        /* Connection : Server IP */
        private const string SERVER_IP = "127.0.0.1";

        /* Connection : Port number */
        private const int PORT_NUMBER = 8004;

        /* Values format */
        private const string FORMAT = "0.000000";

        /* Path to the reference gestures */
        private const string REF_FILEPATH = "C:/Users/JohnDoe/Desktop/Reference";

        /* The length of a calculation frame (59 * 16 + 2 = 946 values) */
        private const int CALCULATION_FRAME_LENGTH = 946;

        /* BVH table of data retrieved, one line equals one frame  */
        private static string[] dataReceived;

        /* Position (X, Y ,Z) of the left hand  */
        private static string[] leftHand_pos;
        private static double[] leftHand_posX;
        private static double[] leftHand_posY;
        private static double[] leftHand_posZ;

        /* Velocity (X, Y ,Z) of the left hand  */
        private static string[] leftHand_vel;
        private static double[] leftHand_velX;
        private static double[] leftHand_velY;
        private static double[] leftHand_velZ;

        /// <summary>
        /// This is the main method.
        /// </summary>
        static void Main(string[] args)
        {
            // Hello text
            Console.WriteLine("===============================================");
            Console.WriteLine("Glove Triggers for Virtual Reality Applications");
            Console.WriteLine("Lucas Alborghetti / HEIA-FR");
            Console.WriteLine("===============================================");
            Console.WriteLine("");

            // Trying to connect to Axis Neuron
            IntPtr connection = IntPtr.Zero;
            Console.WriteLine("Trying to connect to Axis Neuron...");
            connection = NeuronDataReader.BRConnectTo(SERVER_IP, PORT_NUMBER);

            // Set capture over to false
            isOver = false;

            // Test if the connection succeeded
            if (connection == IntPtr.Zero)
            {
                // Connection failed
                Console.WriteLine("[-] Not connected !");
                Close();
            }
            else
            {
                // Connection success
                Console.WriteLine("[+] Connected !");
                Console.WriteLine("");

                // Initial values
                listening = true;
                isRecognition = false;
                total_frames = 100;
                frameCounter = 0;
                gesture_name = "Gesture";

                // Wait for start
                Console.WriteLine("Options :");
                Console.WriteLine("- [X] to record the gesture to add.");
                Console.WriteLine("- [C] to record the gesture to recognize.");
                Console.WriteLine("- [N] to specify the name of the gesture you're about to capture. (Default is 'Gesture')");
                Console.WriteLine("- [Y] to change the number of frames to capture. (Default is '100')");
                Console.WriteLine("- [Q] to quit the program.");
                Console.WriteLine("");

                // Listen to user's keys
                while (listening)
                {
                    Console.WriteLine("Listening...");
                    Console.WriteLine("");
                    var input = Console.ReadKey(true);
                    switch (input.Key)
                    {
                        // -------------------------------------------------------------------------------------------------
                        // User wants to record the gesture to add :
                        case ConsoleKey.X:
                            {
                                Console.WriteLine("Starting the capture...");

                                // Create the tables
                                dataReceived = new string[total_frames];
                                leftHand_pos = new string[total_frames];
                                leftHand_posX = new double[total_frames];
                                leftHand_posY = new double[total_frames];
                                leftHand_posZ = new double[total_frames];
                                leftHand_vel = new string[total_frames];
                                leftHand_velX = new double[total_frames];
                                leftHand_velY = new double[total_frames];
                                leftHand_velZ = new double[total_frames];

                                // Callbacks for data output 
                                FrameDataReceived fdr = new FrameDataReceived(CallbackCalculationDataReceived);

                                // Functions API 
                                NeuronDataReader.BRRegisterCalculationDataCallback(IntPtr.Zero, fdr);

                                // Stop listening
                                listening = false;

                                // Wait for user to quit the program
                                Console.ReadKey();
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to record the gesture to recognize :
                        case ConsoleKey.C:
                            {
                                Console.WriteLine("Starting the capture...");

                                // Recording for recognition
                                isRecognition = true;

                                // Create the tables
                                dataReceived = new string[total_frames];
                                leftHand_pos = new string[total_frames];
                                leftHand_posX = new double[total_frames];
                                leftHand_posY = new double[total_frames];
                                leftHand_posZ = new double[total_frames];
                                leftHand_vel = new string[total_frames];
                                leftHand_velX = new double[total_frames];
                                leftHand_velY = new double[total_frames];
                                leftHand_velZ = new double[total_frames];

                                // Callbacks for data output 
                                FrameDataReceived fdr = new FrameDataReceived(CallbackCalculationDataReceived);

                                // Functions API 
                                NeuronDataReader.BRRegisterCalculationDataCallback(IntPtr.Zero, fdr);

                                // Stop listening
                                listening = false;

                                // Wait for user to quit the program
                                Console.ReadKey();
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to specify the name of the gesture he's about to capture :
                        case ConsoleKey.N:
                            {
                                Console.WriteLine("Enter the name of the gesture you're about to capture :");
                                try
                                {
                                    string temp = Console.ReadLine();
                                    Console.WriteLine("[+] You changed from '" + gesture_name + "' to '" + temp + "'.");
                                    gesture_name = temp;
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine("[-] You entered a wrong name.");
                                }
                                Console.WriteLine("");
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to change the number of frames to capture :
                        case ConsoleKey.Y:
                            {
                                Console.WriteLine("Enter the number of frames to capture :");
                                try
                                {
                                    int temp = int.Parse(Console.ReadLine());
                                    Console.WriteLine("[+] You changed from " + total_frames + " frames to " + temp + " frames.");
                                    total_frames = temp;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine("[-] You entered a wrong number.");
                                }
                                Console.WriteLine("");
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to quit the program :
                        case ConsoleKey.Q:
                            {
                                // Close connection
                                Console.WriteLine("Closing Axis Neuron connection...");
                                Console.WriteLine("");
                                NeuronDataReader.BRCloseSocket(new IntPtr(PORT_NUMBER));
                                listening = false;
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // Unexpected key :
                        default:
                            {
                                Console.WriteLine("[-] Unknown key");
                                Console.WriteLine("");
                                break;
                            }
                    }
                }
            }
        }

        /// <summary>
        /// This method receives the callback from a calculation captured frame with its informations.
        /// </summary>
        public static void CallbackCalculationDataReceived(IntPtr customObject, IntPtr sockRef, IntPtr calculationDataHeader, IntPtr data)
        {
            if (frameCounter < total_frames)
            {
                Console.WriteLine("Processing frame n°" + frameCounter + "...");
                // Retrieve data from current frame
                float[] dataArray = new float[CALCULATION_FRAME_LENGTH];
                CalcDataHeader _calculationHeader = (CalcDataHeader)Marshal.PtrToStructure(calculationDataHeader, typeof(CalcDataHeader));
                if (_calculationHeader.DataCount != dataArray.Length)
                    dataArray = new float[_calculationHeader.DataCount];
                Marshal.Copy(data, dataArray, 0, (int)_calculationHeader.DataCount);

                // ---------------------------------------------------------
                // Position, velocity and quaternion calcul

                // Bone number of left hand is 14 (16 values per bone)
                int leftHandIndex = 14 * 16;

                // Position [cm]
                double posX = dataArray[leftHandIndex + 0];
                double posY = dataArray[leftHandIndex + 1];
                double posZ = dataArray[leftHandIndex + 2];

                // Velocity [cm/s]
                double velX = 0;
                double velY = 0;
                double velZ = 0;
                if (frameCounter >= 2 && frameCounter <= (total_frames - 3))
                {
                    velX = ((leftHand_posX[frameCounter + 1] - leftHand_posX[frameCounter - 1]) + (leftHand_posX[frameCounter + 2] - leftHand_posX[frameCounter - 2])) / 10;
                    velY = ((leftHand_posY[frameCounter + 1] - leftHand_posY[frameCounter - 1]) + (leftHand_posY[frameCounter + 2] - leftHand_posY[frameCounter - 2])) / 10;
                    velZ = ((leftHand_posZ[frameCounter + 1] - leftHand_posZ[frameCounter - 1]) + (leftHand_posZ[frameCounter + 2] - leftHand_posZ[frameCounter - 2])) / 10;
                }

                // To String
                String result_pos = String.Format(posX.ToString(FORMAT)) + "\t" + String.Format(posY.ToString(FORMAT)) + "\t" + String.Format(posZ.ToString(FORMAT));
                String result_vel = String.Format(velX.ToString(FORMAT)) + "\t" + String.Format(velY.ToString(FORMAT)) + "\t" + String.Format(velZ.ToString(FORMAT));

                // Save into array for further write into a file
                leftHand_pos[frameCounter] = result_pos;
                leftHand_posX[frameCounter] = posX;
                leftHand_posY[frameCounter] = posY;
                leftHand_posZ[frameCounter] = posZ;

                leftHand_vel[frameCounter] = result_vel;
                leftHand_velX[frameCounter] = velX;
                leftHand_velY[frameCounter] = velY;
                leftHand_velZ[frameCounter] = velZ;

                // Create a new line for the current frame
                for (int i = 0; i < dataArray.Length; i++)
                    dataReceived[frameCounter] += String.Format(dataArray[i].ToString(FORMAT) + "\t");
                frameCounter++;
            }
            else
            {
                // Set capture over to true
                isOver = true;
                // Save data
                WriteFile(leftHand_pos, gesture_name + "_Position");
                WriteFile(leftHand_vel, gesture_name + "_Velocity");
                // Close connection
                Close();
            }
        }

        /// <summary>
        /// This method writes data into a file in the desktop directory.
        /// </summary>
        private static void WriteFile(string[] data, string filename)
        {
            // Set a variable to the desktop
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            // Write the string array to a new file named "WriteLines.txt".
            using (StreamWriter outputFile = new StreamWriter(path + @"\" + filename + ".txt"))
            {
                foreach (string line in data)
                    outputFile.WriteLine(line);
            }
        }

        /// <summary>
        /// This method reads X,Y,Z data from a file in the desktop directory.
        /// </summary>
        private static List<double[]> ReadFile(string filepath, string filename)
        {
            List<double[]> ref_data = new List<double[]>();

            using (StreamReader reader = new StreamReader(filepath + "/" + filename))
            {
                long fileLength = File.ReadLines(filepath + "/" + filename).Count();
                double[] valX = new double[fileLength];
                double[] valY = new double[fileLength];
                double[] valZ = new double[fileLength];
                int i = 0;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split('\t');
                    valX[i] = Double.Parse(values[0]);
                    valY[i] = Double.Parse(values[1]);
                    valZ[i] = Double.Parse(values[2]);
                    i++;
                }
                ref_data.Add(valX);
                ref_data.Add(valY);
                ref_data.Add(valZ);
            }
            return ref_data;
        }

        /// <summary>
        /// This method calculates the cost between the ref and captured gestures (position)
        /// </summary>
        private static void GetCostPosition(string ref_filename)
        {
            List<double[]> ref_data = ReadFile(REF_FILEPATH, ref_filename);

            SimpleDTW dtwX = new SimpleDTW(ref_data[0], leftHand_posX);
            SimpleDTW dtwY = new SimpleDTW(ref_data[1], leftHand_posY);
            SimpleDTW dtwZ = new SimpleDTW(ref_data[2], leftHand_posZ);

            Console.WriteLine("Costs for position : " + (dtwX.DTWDistance() + dtwY.DTWDistance() + dtwZ.DTWDistance()) + " (X : " + dtwX.DTWDistance() + ", Y : " + dtwY.DTWDistance() + ", Z : " + dtwZ.DTWDistance() + ")");
        }

        /// <summary>
        /// This method calculates the cost between the ref and captured gestures (velocity)
        /// </summary>
        private static void GetCostVelocity(string ref_filename)
        {
            List<double[]> ref_data = ReadFile(REF_FILEPATH, ref_filename);

            SimpleDTW dtwX = new SimpleDTW(ref_data[0], leftHand_velX);
            SimpleDTW dtwY = new SimpleDTW(ref_data[1], leftHand_velY);
            SimpleDTW dtwZ = new SimpleDTW(ref_data[2], leftHand_velZ);

            Console.WriteLine("Costs for velocity : " + (dtwX.DTWDistance() + dtwY.DTWDistance() + dtwZ.DTWDistance()) + " (X : " + dtwX.DTWDistance() + ", Y : " + dtwY.DTWDistance() + ", Z : " + dtwZ.DTWDistance() + ")");
        }

        /// <summary>
        /// This method calculates the costs.
        /// </summary>
        private static void CalculateCosts()
        {
            Console.WriteLine("");
            Console.WriteLine("---------------------------------");
            Console.WriteLine("- DTW with swipe left (1)       -");
            Console.WriteLine("---------------------------------");

            // Calculting costs
            GetCostPosition("SwipeLeft1_Position.txt");
            GetCostVelocity("SwipeLeft1_Velocity.txt");

            Console.WriteLine("---------------------------------");
            Console.WriteLine("- DTW with swipe left (2)       -");
            Console.WriteLine("---------------------------------");

            // Calculting costs
            GetCostPosition("SwipeLeft2_Position.txt");
            GetCostVelocity("SwipeLeft2_Velocity.txt");

            Console.WriteLine("---------------------------------");
            Console.WriteLine("- DTW with swipe left (3)       -");
            Console.WriteLine("---------------------------------");

            // Calculting costs
            GetCostPosition("SwipeLeft3_Position.txt");
            GetCostVelocity("SwipeLeft3_Velocity.txt");
        }

        /// <summary>
        /// This method ends the program by closing the socket and the console.
        /// </summary>
        private static void Close()
        {
            if (isOver)
            {
                if (isRecognition)
                    CalculateCosts();

                // Close connection
                Console.WriteLine("");
                Console.WriteLine("Closing Axis Neuron connection...");
                Console.WriteLine("");
                NeuronDataReader.BRCloseSocket(new IntPtr(PORT_NUMBER));
            }

            // Wait for the user to close the program
            Console.WriteLine("");
            Console.WriteLine("Press any key to quit the program.");
            Console.ReadKey();
        }
    }
}
