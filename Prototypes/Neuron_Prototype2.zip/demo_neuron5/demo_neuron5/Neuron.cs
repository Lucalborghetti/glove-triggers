﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace demo_neuron5
{
    class Neuron
    {
        /* Is listening to user's key */
        private static Boolean isListening;

        /* Is gesture capture over */
        private static Boolean isOver;

        /* Is recording for recognition */
        private static Boolean isRecognition;

        /* The number of frame to capture */
        private static int total_frames;

        /* The name of the gesture to capture */
        private static string gesture_name;

        /* The current number of frame retrieved */
        private static int frameCounter;

        /* The sensors from which the data must be captured */
        private static List<Sensor> sensors;

        /* Sensor : Left arm sensor */
        private static Sensor leftArm;

        /* Sensor : Left fore arm sensor */
        private static Sensor leftForeArm;

        /* Sensor : Left hand sensor */
        private static Sensor leftHand;

        /* Data (position and velocity) of the gesture */
        private static string[] gesture_data;

        /* Cost of the gesture compared to the reference gestures */
        private static Dictionary<string, double> gesture_costs;

        /// <summary>
        /// This is the main method.
        /// </summary>
        static void Main(string[] args)
        {
            // Hello text
            Console.WriteLine("===============================================");
            Console.WriteLine("Glove Triggers for Virtual Reality Applications");
            Console.WriteLine("Lucas Alborghetti / HEIA-FR");
            Console.WriteLine("===============================================");
            Console.WriteLine("");

            // Trying to connect to Axis Neuron
            IntPtr connection = IntPtr.Zero;
            Console.WriteLine("Trying to connect to Axis Neuron...");
            connection = NeuronDataReader.BRConnectTo(Consts.SERVER_IP, Consts.PORT_NUMBER);

            // Set capture over to false
            isOver = false;

            // Test if the connection succeeded
            if (connection == IntPtr.Zero)
            {
                // Connection failed
                Console.WriteLine("[-] Not connected !");
                Close();
            }
            else
            {
                // Connection success
                Console.WriteLine("[+] Connected !");
                Console.WriteLine("");

                // Initial values
                InitValues();

                // Wait for start
                Console.WriteLine("Options :");
                Console.WriteLine("- [X] to record a gesture to add as reference.");
                Console.WriteLine("- [C] to record a gesture to recognize.");
                Console.WriteLine("- [N] to specify the name of the gesture you're about to capture. (Default is '" + gesture_name + "')");
                Console.WriteLine("- [Y] to change the number of frames to capture. (Default is '" + total_frames + "')");
                Console.WriteLine("- [Q] to quit the program.");
                Console.WriteLine("");

                // Listen to user's keys
                while (isListening)
                {
                    Console.WriteLine("Listening...");
                    Console.WriteLine("");
                    var input = Console.ReadKey(true);
                    switch (input.Key)
                    {
                        // -------------------------------------------------------------------------------------------------
                        // User wants to record the gesture to add :
                        case ConsoleKey.X:
                            {
                                Console.WriteLine("Starting the capture...");

                                // Create the tables
                                InitTables();

                                // Callbacks for data output 
                                FrameDataReceived fdr = new FrameDataReceived(CallbackCalculationDataReceived);

                                // Functions API 
                                NeuronDataReader.BRRegisterCalculationDataCallback(IntPtr.Zero, fdr);

                                // Stop listening
                                isListening = false;

                                // Wait for user to quit the program
                                Console.ReadKey();
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to record the gesture to recognize :
                        case ConsoleKey.C:
                            {
                                Console.WriteLine("Starting the capture...");

                                // Recording for recognition
                                isRecognition = true;

                                // Create the tables
                                InitTables();

                                // Callbacks for data output 
                                FrameDataReceived fdr = new FrameDataReceived(CallbackCalculationDataReceived);

                                // Functions API 
                                NeuronDataReader.BRRegisterCalculationDataCallback(IntPtr.Zero, fdr);

                                // Stop listening
                                isListening = false;

                                // Wait for user to quit the program
                                Console.ReadKey();
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to specify the name of the gesture he's about to capture :
                        case ConsoleKey.N:
                            {
                                Console.WriteLine("Enter the name of the gesture you're about to capture :");
                                try
                                {
                                    string temp = Console.ReadLine();
                                    Console.WriteLine("[+] You changed from '" + gesture_name + "' to '" + temp + "'.");
                                    gesture_name = temp;
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine("[-] You entered a wrong name.");
                                }
                                Console.WriteLine("");
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to change the number of frames to capture :
                        case ConsoleKey.Y:
                            {
                                Console.WriteLine("Enter the number of frames to capture :");
                                try
                                {
                                    int temp = int.Parse(Console.ReadLine());
                                    Console.WriteLine("[+] You changed from " + total_frames + " frames to " + temp + " frames.");
                                    total_frames = temp;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine("[-] You entered a wrong number.");
                                }
                                Console.WriteLine("");
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // User wants to quit the program :
                        case ConsoleKey.Q:
                            {
                                // Close connection
                                Console.WriteLine("Closing Axis Neuron connection...");
                                Console.WriteLine("");
                                NeuronDataReader.BRCloseSocket(new IntPtr(Consts.PORT_NUMBER));
                                isListening = false;
                                break;
                            }
                        // -------------------------------------------------------------------------------------------------
                        // Unexpected key :
                        default:
                            {
                                Console.WriteLine("[-] Unknown key");
                                Console.WriteLine("");
                                break;
                            }
                    }
                }
            }
        }

        /// <summary>
        /// This method initialize the values.
        /// </summary>
        private static void InitValues()
        {
            isListening = true;
            isRecognition = false;
            total_frames = 100;
            frameCounter = 0;
            gesture_name = "Gesture";
            sensors = new List<Sensor>();
        }

        /// <summary>
        /// This method initialize the gesture tables.
        /// </summary>
        private static void InitTables()
        {
            /* Cost of the gesture compared to the reference one */
            gesture_costs = new Dictionary<string, double>();

            /* Data (position and velocity) of the gesture */
            gesture_data = new string[total_frames];

            /* Left arm sensors */
            leftArm = new Sensor(12 * 16, total_frames);
            sensors.Add(leftArm);
            leftForeArm = new Sensor(13 * 16, total_frames);
            sensors.Add(leftForeArm);
            leftHand = new Sensor(14 * 16, total_frames);
            sensors.Add(leftHand);
        }

        /// <summary>
        /// This method receives the callback from a calculation captured frame with its informations.
        /// </summary>
        public static void CallbackCalculationDataReceived(IntPtr customObject, IntPtr sockRef, IntPtr calculationDataHeader, IntPtr data)
        {
            if (frameCounter < total_frames)
            {
                Console.WriteLine("Processing frame n°" + frameCounter + "...");
                // Retrieve data from current frame
                float[] dataArray = new float[Consts.CALCULATION_FRAME_LENGTH];
                CalcDataHeader _calculationHeader = (CalcDataHeader)Marshal.PtrToStructure(calculationDataHeader, typeof(CalcDataHeader));
                if (_calculationHeader.DataCount != dataArray.Length)
                    dataArray = new float[_calculationHeader.DataCount];
                Marshal.Copy(data, dataArray, 0, (int)_calculationHeader.DataCount);

                // For each sensor, get the position

                foreach (Sensor sensor in sensors)
                {
                    int sensorIndex = sensor.GetIndex();
                    // Position
                    sensor.SetPosXatIndex(frameCounter, dataArray[sensorIndex + 0]);
                    sensor.SetPosYatIndex(frameCounter, dataArray[sensorIndex + 1]);
                    sensor.SetPosZatIndex(frameCounter, dataArray[sensorIndex + 2]);
                }

                // Next frame
                frameCounter++;
            }
            else
            {
                // Set capture over to true
                isOver = true;
                // From each sensor, calculate the velocity
                CalculateVelocity();
                // Save data
                WriteFile(gesture_data, gesture_name + "_data");
                // Close connection
                Close();
            }
        }

        /// <summary>
        /// This method calculates the velocity based on the positions captured.
        /// </summary>
        private static void CalculateVelocity()
        {
            // For each sensor, get the position and the velocity
            for (int i = 0; i < total_frames; i++)
            {
                foreach (Sensor sensor in sensors)
                {
                    double velX = 0;
                    double velY = 0;
                    double velZ = 0;

                    // Velocity
                    if (i >= 2 && i <= (total_frames - 3))
                    {
                        velX = ((sensor.GetPosXatIndex(i + 1) - sensor.GetPosXatIndex(i - 1)) + (sensor.GetPosXatIndex(i + 2) - sensor.GetPosXatIndex(i - 2))) / 10;
                        velY = ((sensor.GetPosYatIndex(i + 1) - sensor.GetPosYatIndex(i - 1)) + (sensor.GetPosYatIndex(i + 2) - sensor.GetPosYatIndex(i - 2))) / 10;
                        velZ = ((sensor.GetPosZatIndex(i + 1) - sensor.GetPosZatIndex(i - 1)) + (sensor.GetPosZatIndex(i + 2) - sensor.GetPosZatIndex(i - 2))) / 10;
                    }
                    sensor.SetVelXatIndex(i, velX);
                    sensor.SetVelYatIndex(i, velY);
                    sensor.SetVelZatIndex(i, velZ);
                }
                // Save the frame data
                gesture_data[i] = leftArm.PositionToString(i, Consts.FORMAT) + "\t" + leftArm.VelocityToString(i, Consts.FORMAT) + "\t" + leftForeArm.PositionToString(i, Consts.FORMAT) + "\t" + leftForeArm.VelocityToString(i, Consts.FORMAT) + "\t" + leftHand.PositionToString(i, Consts.FORMAT) + "\t" + leftHand.VelocityToString(i, Consts.FORMAT);
            }
        }

        /// <summary>
        /// This method calculates the costs between the reference gestures and the captured one.
        /// </summary>
        private static void CalculateCosts()
        {
            Console.WriteLine("");
            Console.WriteLine("=============================================");
            Console.WriteLine("You captured the '" + gesture_name + "' gesture.");
            Console.WriteLine("=============================================");
            Console.WriteLine("");
            
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(Consts.REFERENCE_PATH);
            foreach (string fileName in fileEntries)
            {
                List<double[]> ref_data = ReadFile(Consts.REFERENCE_PATH, fileName);

                // -------------------------------------------------------
                //SimpleDTW leftArm_pos_dtwX = new SimpleDTW(ref_data[0], leftArm_posX);
                //SimpleDTW leftArm_pos_dtwY = new SimpleDTW(ref_data[1], leftArm_posY);
                //SimpleDTW leftArm_pos_dtwZ = new SimpleDTW(ref_data[2], leftArm_posZ);
                SimpleDTW leftArm_vel_dtwX = new SimpleDTW(ref_data[3], leftArm.GetVelX());
                SimpleDTW leftArm_vel_dtwY = new SimpleDTW(ref_data[4], leftArm.GetVelY());
                SimpleDTW leftArm_vel_dtwZ = new SimpleDTW(ref_data[5], leftArm.GetVelZ());
                // -------------------------------------------------------
                //SimpleDTW leftForeArm_pos_dtwX = new SimpleDTW(ref_data[6], leftForeArm_posX);
                //SimpleDTW leftForeArm_pos_dtwY = new SimpleDTW(ref_data[7], leftForeArm_posY);
                //SimpleDTW leftForeArm_pos_dtwZ = new SimpleDTW(ref_data[8], leftForeArm_posZ);
                SimpleDTW leftForeArm_vel_dtwX = new SimpleDTW(ref_data[9], leftForeArm.GetVelX());
                SimpleDTW leftForeArm_vel_dtwY = new SimpleDTW(ref_data[10], leftForeArm.GetVelY());
                SimpleDTW leftForeArm_vel_dtwZ = new SimpleDTW(ref_data[11], leftForeArm.GetVelZ());
                // -------------------------------------------------------
                //SimpleDTW leftHand_pos_dtwX = new SimpleDTW(ref_data[12], leftHand_posX);
                //SimpleDTW leftHand_pos_dtwY = new SimpleDTW(ref_data[13], leftHand_posY);
                //SimpleDTW leftHand_pos_dtwZ = new SimpleDTW(ref_data[14], leftHand_posZ);
                SimpleDTW leftHand_vel_dtwX = new SimpleDTW(ref_data[15], leftHand.GetVelX());
                SimpleDTW leftHand_vel_dtwY = new SimpleDTW(ref_data[16], leftHand.GetVelY());
                SimpleDTW leftHand_vel_dtwZ = new SimpleDTW(ref_data[17], leftHand.GetVelZ());
                // -------------------------------------------------------

                double leftArmCost = leftArm_vel_dtwX.DTWDistance() + leftArm_vel_dtwY.DTWDistance() + leftArm_vel_dtwZ.DTWDistance();
                double leftForeArmCost = leftForeArm_vel_dtwX.DTWDistance() + leftForeArm_vel_dtwY.DTWDistance() + leftForeArm_vel_dtwZ.DTWDistance();
                double leftHandCost = leftHand_vel_dtwX.DTWDistance() + leftHand_vel_dtwY.DTWDistance() + leftHand_vel_dtwZ.DTWDistance();
                double totalCost = leftArmCost + leftForeArmCost + leftHandCost;

                Console.WriteLine("-----------------------------------------------");
                Console.WriteLine(Path.GetFileName(fileName) + "\t [Cost : " + totalCost + " (" + leftArmCost + " ; " + leftForeArmCost + " ; " + leftHandCost + ")]");

                gesture_costs[fileName] = totalCost;
            }

            var keyAndValue = gesture_costs.OrderBy(kvp => kvp.Value).First();
            Console.WriteLine("");
            Console.WriteLine("================================================================");
            Console.WriteLine("Closest gesture : " + Path.GetFileName(keyAndValue.Key) + " [Cost :" + keyAndValue.Value + "]");
            Console.WriteLine("================================================================");
        }

        /// <summary>
        /// This method normalizes the data.
        /// </summary>
        private static double[] Normalize(double[] data)
        {
            // Calculte the mean
            double sum = 0.0;
            for(int i = 0; i < data.Length; i++)
                sum += data[i];
            double mean = (sum / data.Length);

            // Calculate the variance
            double sum2 = 0.0;
            for (int i = 0; i < data.Length; i++)
                sum2 += Math.Pow((data[i] - mean), 2);;
            double variance = (sum2 / data.Length);

            // Calculate the standard deviation
            double deviation = Math.Sqrt(variance);

            // Normalize the data
            double[] normalized_data = new double[data.Length];
            for (int i = 0; i < data.Length; i++)
                normalized_data[i] += ((data[i] - mean) / deviation);

            return normalized_data;
        }

        /// <summary>
        /// This method writes data into a file in the desktop directory.
        /// </summary>
        private static void WriteFile(string[] data, string filename)
        {
            // Set a variable to the desktop
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            // Write the string array to a new file named "WriteLines.txt".
            using (StreamWriter outputFile = new StreamWriter(path + @"\" + filename + ".txt"))
            {
                foreach (string line in data)
                    outputFile.WriteLine(line);
            }
        }

        /// <summary>
        /// This method reads X,Y,Z data from a file in the desktop directory.
        /// </summary>
        private static List<double[]> ReadFile(string filepath, string filename)
        {
            List<double[]> ref_data = new List<double[]>();

            using (StreamReader reader = new StreamReader(filename))
            {
                long fileLength = File.ReadLines(filename).Count();
                // -----------------------------------------------
                double[] leftArm_pos_valX = new double[fileLength];
                double[] leftArm_pos_valY = new double[fileLength];
                double[] leftArm_pos_valZ = new double[fileLength];
                double[] leftArm_vel_valX = new double[fileLength];
                double[] leftArm_vel_valY = new double[fileLength];
                double[] leftArm_vel_valZ = new double[fileLength];
                // -----------------------------------------------
                double[] leftForeArm_pos_valX = new double[fileLength];
                double[] leftForeArm_pos_valY = new double[fileLength];
                double[] leftForeArm_pos_valZ = new double[fileLength];
                double[] leftForeArm_vel_valX = new double[fileLength];
                double[] leftForeArm_vel_valY = new double[fileLength];
                double[] leftForeArm_vel_valZ = new double[fileLength];
                // -----------------------------------------------
                double[] leftHand_pos_valX = new double[fileLength];
                double[] leftHand_pos_valY = new double[fileLength];
                double[] leftHand_pos_valZ = new double[fileLength];
                double[] leftHand_vel_valX = new double[fileLength];
                double[] leftHand_vel_valY = new double[fileLength];
                double[] leftHand_vel_valZ = new double[fileLength];
                // -----------------------------------------------
                int i = 0;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split('\t');
                    // -----------------------------------------------
                    leftArm_pos_valX[i] = Double.Parse(values[0]);
                    leftArm_pos_valY[i] = Double.Parse(values[1]);
                    leftArm_pos_valZ[i] = Double.Parse(values[2]);
                    leftArm_vel_valX[i] = Double.Parse(values[3]);
                    leftArm_vel_valY[i] = Double.Parse(values[4]);
                    leftArm_vel_valZ[i] = Double.Parse(values[5]);
                    // -----------------------------------------------
                    leftForeArm_pos_valX[i] = Double.Parse(values[6]);
                    leftForeArm_pos_valY[i] = Double.Parse(values[7]);
                    leftForeArm_pos_valZ[i] = Double.Parse(values[8]);
                    leftForeArm_vel_valX[i] = Double.Parse(values[9]);
                    leftForeArm_vel_valY[i] = Double.Parse(values[10]);
                    leftForeArm_vel_valZ[i] = Double.Parse(values[11]);
                    // -----------------------------------------------
                    leftHand_pos_valX[i] = Double.Parse(values[12]);
                    leftHand_pos_valY[i] = Double.Parse(values[13]);
                    leftHand_pos_valZ[i] = Double.Parse(values[14]);
                    leftHand_vel_valX[i] = Double.Parse(values[15]);
                    leftHand_vel_valY[i] = Double.Parse(values[16]);
                    leftHand_vel_valZ[i] = Double.Parse(values[17]);
                    // -----------------------------------------------
                    i++;
                }
                // -----------------------------------------------
                ref_data.Add(leftArm_pos_valX);
                ref_data.Add(leftArm_pos_valY);
                ref_data.Add(leftArm_pos_valZ);
                ref_data.Add(leftArm_vel_valX);
                ref_data.Add(leftArm_vel_valY);
                ref_data.Add(leftArm_vel_valZ);
                // -----------------------------------------------
                ref_data.Add(leftForeArm_pos_valX);
                ref_data.Add(leftForeArm_pos_valY);
                ref_data.Add(leftForeArm_pos_valZ);
                ref_data.Add(leftForeArm_vel_valX);
                ref_data.Add(leftForeArm_vel_valY);
                ref_data.Add(leftForeArm_vel_valZ);
                // -----------------------------------------------
                ref_data.Add(leftHand_pos_valX);
                ref_data.Add(leftHand_pos_valY);
                ref_data.Add(leftHand_pos_valZ);
                ref_data.Add(leftHand_vel_valX);
                ref_data.Add(leftHand_vel_valY);
                ref_data.Add(leftHand_vel_valZ);
                // -----------------------------------------------
            }
            return ref_data;
        }

                /// <summary>
        /// This method ends the program by closing the socket and the console.
        /// </summary>
        private static void Close()
        {
            if (isOver)
            {
                if (isRecognition)
                    CalculateCosts();

                // Close connection
                Console.WriteLine("");
                Console.WriteLine("Closing Axis Neuron connection...");
                Console.WriteLine("");
                NeuronDataReader.BRCloseSocket(new IntPtr(Consts.PORT_NUMBER));
            }

            // Wait for the user to close the program
            Console.WriteLine("");
            Console.WriteLine("Press any key to quit the program.");
            Console.ReadKey();
        }
    }
}
