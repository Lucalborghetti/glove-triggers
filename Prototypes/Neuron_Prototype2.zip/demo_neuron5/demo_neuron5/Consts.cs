﻿namespace demo_neuron5
{
    class Consts
    {
        /* Connection : Server IP */
        public const string SERVER_IP = "127.0.0.1";

        /* Connection : Port number */
        public const int PORT_NUMBER = 8004;

        /* Values format */
        public const string FORMAT = "0.000000";

        /* Calculation frame length (59 * 16 + 2 = 946 values) */
        public const int CALCULATION_FRAME_LENGTH = 946;

        /* 'Reference gestures' directory path */
        public const string REFERENCE_PATH = "C:/Users/JohnDoe/Desktop/Reference";

        /* 'Captured gestures' directory path */
        public const string CAPTURED_PATH = "C:/Users/JohnDoe/Desktop/Captured";
    }
}
