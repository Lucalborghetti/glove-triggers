﻿using System;

namespace demo_neuron5
{
    class Sensor
    {
        /* Index of the sensor */
        private int index;

        /* Sensor positions */
        private double[] sensor_posX;
        private double[] sensor_posY;
        private double[] sensor_posZ;

        /* Sensor velocities */
        private double[] sensor_velX;
        private double[] sensor_velY;
        private double[] sensor_velZ;

        public Sensor(int index, int total_frames)
        {
            this.index = index;
            sensor_posX = new double[total_frames];
            sensor_posY = new double[total_frames];
            sensor_posZ = new double[total_frames];
            sensor_velX = new double[total_frames];
            sensor_velY = new double[total_frames];
            sensor_velZ = new double[total_frames];
        }

        /* ------------------------------------------------------- */

        public int GetIndex()
        {
            return index;
        }

        /* ------------------------------------------------------- */

        public double[] GetPosX()
        {
            return sensor_posX;
        }

        public double GetPosXatIndex(int i)
        {
            return sensor_posX[i];
        }

        public void SetPosX(double[] posX)
        {
            sensor_posX = posX;
        }

        public void SetPosXatIndex(int i, double value)
        {
            sensor_posX[i] = value;
        }

        public double[] GetPosY()
        {
            return sensor_posY;
        }

        public double GetPosYatIndex(int i)
        {
            return sensor_posY[i];
        }

        public void SetPosY(double[] posY)
        {
            sensor_posY = posY;
        }

        public void SetPosYatIndex(int i, double value)
        {
            sensor_posY[i] = value;
        }

        public double[] GetPosZ()
        {
            return sensor_posZ;
        }

        public double GetPosZatIndex(int i)
        {
            return sensor_posZ[i];
        }

        public void SetPosZ(double[] posZ)
        {
            sensor_posZ = posZ;
        }

        public void SetPosZatIndex(int i, double value)
        {
            sensor_posZ[i] = value;
        }

        public string PositionToString(int i, string format)
        {
            return String.Format(sensor_posX[i].ToString(format)) + "\t" + String.Format(sensor_posY[i].ToString(format)) + "\t" + String.Format(sensor_posZ[i].ToString(format));
        }

        /* ------------------------------------------------------- */

        public double[] GetVelX()
        {
            return sensor_velX;
        }

        public double GetVelXatIndex(int i)
        {
            return sensor_velX[i];
        }

        public void SetVelX(double[] velX)
        {
            sensor_velX = velX;
        }

        public void SetVelXatIndex(int i, double value)
        {
            sensor_velX[i] = value;
        }

        public double[] GetVelY()
        {
            return sensor_velY;
        }

        public double GetVelYatIndex(int i)
        {
            return sensor_velY[i];
        }

        public void SetVelY(double[] velY)
        {
            sensor_velY = velY;
        }

        public void SetVelYatIndex(int i, double value)
        {
            sensor_velY[i] = value;
        }

        public double[] GetVelZ()
        {
            return sensor_velZ;
        }

        public double GetVelZatIndex(int i)
        {
            return sensor_velZ[i];
        }

        public void SetVelZ(double[] velZ)
        {
            sensor_velZ = velZ;
        }

        public void SetVelZatIndex(int i, double value)
        {
            sensor_velZ[i] = value;
        }

        public string VelocityToString(int i, string format)
        {
            return String.Format(sensor_velX[i].ToString(format)) + "\t" + String.Format(sensor_velY[i].ToString(format)) + "\t" + String.Format(sensor_velZ[i].ToString(format));
        }

    }
}
